import { Router } from "express";
import { randomBytes, createHash } from "node:crypto";
import argon2 from "argon2";
import { z } from "zod";
import { prisma } from "../db.js";
import { requireAuth, requireCsrf, issueCsrfToken } from "../middleware/security.js";

const router = Router();
const EMAIL_PATTERN = /^[A-Za-z0-9._%+-]+@ajyal\.jo$/i;
const passwordSchema = z.string().min(10, "كلمة المرور يجب أن تتكون من 10 أحرف على الأقل.")
  .max(128, "كلمة المرور طويلة جدًا.")
  .refine(v => /[a-z]/.test(v), "أضف حرفًا إنجليزيًا صغيرًا.")
  .refine(v => /[A-Z]/.test(v), "أضف حرفًا إنجليزيًا كبيرًا.")
  .refine(v => /\d/.test(v), "أضف رقمًا واحدًا على الأقل.")
  .refine(v => /[^A-Za-z0-9]/.test(v), "أضف رمزًا خاصًا واحدًا على الأقل.");

const registerSchema = z.object({
  displayName: z.string().trim().min(2).max(24),
  email: z.string().trim().toLowerCase().email().regex(EMAIL_PATTERN, "يرجى استخدام بريدك الإلكتروني المنتهي بـ @ajyal.jo."),
  password: passwordSchema,
  confirmPassword: z.string(),
  schoolName: z.string().trim().max(70).optional().default(""),
  character: z.enum(["DETECTIVE", "RACER"]).default("DETECTIVE"),
  avatarColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/).default("#8b6ce8"),
  accessory: z.string().max(12).default("✨")
}).refine(v => v.password === v.confirmPassword, {
  message: "كلمتا المرور غير متطابقتين.",
  path: ["confirmPassword"]
});

const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email().regex(EMAIL_PATTERN, "البريد يجب أن ينتهي بـ @ajyal.jo."),
  password: z.string().min(1).max(128)
});

function publicUser(user) {
  return {
    id: user.id,
    email: user.email,
    role: user.role,
    student: user.student ? {
      displayName: user.student.displayName,
      schoolName: user.student.school?.name ?? "",
      character: user.student.character,
      avatarColor: user.student.avatarColor,
      accessory: user.student.accessory
    } : null
  };
}
function hashToken(token) {
  return createHash("sha256").update(token).digest("hex");
}
function regenerateSession(req) {
  return new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
}
function saveSession(req) {
  return new Promise((resolve, reject) => req.session.save(err => err ? reject(err) : resolve()));
}

router.get("/csrf", issueCsrfToken);

router.post("/register", requireCsrf, async (req, res, next) => {
  try {
    const parsed = registerSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: parsed.error.issues[0]?.message || "يرجى مراجعة البيانات." });
    }
    const data = parsed.data;
    const existing = await prisma.user.findUnique({ where: { email: data.email } });
    if (existing) return res.status(409).json({ error: "هذا البريد مسجل مسبقًا." });

    let school = null;
    if (data.schoolName) {
      school = await prisma.school.upsert({
        where: { name: data.schoolName },
        update: {},
        create: { name: data.schoolName }
      });
    }
    const passwordHash = await argon2.hash(data.password, { type: argon2.argon2id });
    const user = await prisma.user.create({
      data: {
        email: data.email,
        passwordHash,
        role: "STUDENT",
        student: {
          create: {
            displayName: data.displayName,
            schoolId: school?.id,
            character: data.character,
            avatarColor: data.avatarColor,
            accessory: data.accessory
          }
        }
      },
      include: { student: { include: { school: true } } }
    });
    await regenerateSession(req);
    req.session.userId = user.id;
    req.session.role = user.role;
    await saveSession(req);
    res.status(201).json({ message: "تم إنشاء حسابك بنجاح.", user: publicUser(user) });
  } catch (error) {
    if (error?.code === "P2002") return res.status(409).json({ error: "هذا البريد مسجل مسبقًا." });
    next(error);
  }
});

router.post("/login", requireCsrf, async (req, res, next) => {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error.issues[0]?.message || "بيانات الدخول غير صحيحة." });
    const user = await prisma.user.findUnique({
      where: { email: parsed.data.email },
      include: { student: { include: { school: true } } }
    });
    if (!user || !user.isActive || !(await argon2.verify(user.passwordHash, parsed.data.password))) {
      return res.status(401).json({ error: "البريد الإلكتروني أو كلمة المرور غير صحيحة." });
    }
    await regenerateSession(req);
    req.session.userId = user.id;
    req.session.role = user.role;
    await saveSession(req);
    res.json({ message: "تم تسجيل الدخول بنجاح.", user: publicUser(user) });
  } catch (error) { next(error); }
});

router.get("/me", requireAuth, async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.session.userId },
      include: { student: { include: { school: true } } }
    });
    if (!user || !user.isActive) return res.status(401).json({ error: "الحساب غير متاح." });
    res.json({ user: publicUser(user) });
  } catch (error) { next(error); }
});

router.post("/logout", requireAuth, requireCsrf, (req, res, next) => {
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie("wmh.sid");
    res.json({ message: "تم تسجيل الخروج." });
  });
});

router.post("/forgot-password", requireCsrf, (_req, res) => {
  res.status(501).json({ error: "استعادة كلمة المرور غير متاحة حاليًا. يرجى التواصل مع إدارة النظام." });
});

router.post("/reset-password", requireCsrf, async (req, res, next) => {
  try {
    const token = String(req.body?.token || "");
    const passwordResult = passwordSchema.safeParse(req.body?.password);
    if (!token || !passwordResult.success) {
      return res.status(400).json({ error: passwordResult.success ? "رابط الاستعادة غير صالح." : passwordResult.error.issues[0]?.message });
    }
    const record = await prisma.passwordResetToken.findUnique({ where: { tokenHash: hashToken(token) } });
    if (!record || record.usedAt || record.expiresAt < new Date()) return res.status(400).json({ error: "انتهت صلاحية رابط الاستعادة أو أنه غير صالح." });
    const passwordHash = await argon2.hash(passwordResult.data, { type: argon2.argon2id });
    await prisma.$transaction([
      prisma.user.update({ where: { id: record.userId }, data: { passwordHash } }),
      prisma.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
      prisma.passwordResetToken.deleteMany({ where: { userId: record.userId, id: { not: record.id } } })
    ]);
    res.json({ message: "تم تحديث كلمة المرور. يمكنك تسجيل الدخول الآن." });
  } catch (error) { next(error); }
});

export default router;
