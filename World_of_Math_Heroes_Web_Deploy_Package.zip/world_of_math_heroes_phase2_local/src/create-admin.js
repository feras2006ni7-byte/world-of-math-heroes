import "dotenv/config";
import argon2 from "argon2";
import { z } from "zod";
import { prisma } from "./db.js";

const schema = z.object({
  email: z.string().email().transform(v => v.toLowerCase()),
  password: z.string().min(12),
  displayName: z.string().min(2).max(80)
});
const parsed = schema.safeParse({
  email: process.env.ADMIN_EMAIL,
  password: process.env.ADMIN_PASSWORD,
  displayName: process.env.ADMIN_DISPLAY_NAME || "مدير النظام"
});
if (!parsed.success) {
  console.error("Set ADMIN_EMAIL, ADMIN_PASSWORD (12+ characters), and optionally ADMIN_DISPLAY_NAME in .env");
  process.exit(1);
}
const data = parsed.data;
const passwordHash = await argon2.hash(data.password, { type: argon2.argon2id });
await prisma.user.upsert({
  where: { email: data.email },
  update: { passwordHash, role: "ADMIN", isActive: true },
  create: { email: data.email, passwordHash, role: "ADMIN" }
});
console.log(`Admin account provisioned: ${data.email}`);
await prisma.$disconnect();
