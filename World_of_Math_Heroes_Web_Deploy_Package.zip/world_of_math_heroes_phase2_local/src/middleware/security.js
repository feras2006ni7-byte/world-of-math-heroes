import { randomBytes, timingSafeEqual } from "node:crypto";

export function issueCsrfToken(req, res) {
  if (!req.session.csrfToken) req.session.csrfToken = randomBytes(32).toString("hex");
  res.json({ csrfToken: req.session.csrfToken });
}

export function requireCsrf(req, res, next) {
  const supplied = req.get("x-csrf-token") || "";
  const expected = req.session?.csrfToken || "";
  if (!supplied || !expected) return res.status(403).json({ error: "تعذر التحقق من الطلب. حدّث الصفحة وحاول مجددًا." });
  const a = Buffer.from(supplied);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    return res.status(403).json({ error: "رمز الحماية غير صالح." });
  }
  next();
}

export function requireAuth(req, res, next) {
  if (!req.session?.userId) return res.status(401).json({ error: "يرجى تسجيل الدخول أولًا." });
  next();
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.session?.userId || !roles.includes(req.session.role)) {
      return res.status(403).json({ error: "ليس لديك صلاحية للوصول إلى هذه الصفحة." });
    }
    next();
  };
}
