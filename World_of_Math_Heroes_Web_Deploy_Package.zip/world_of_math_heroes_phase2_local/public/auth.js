const $ = s => document.querySelector(s);
let csrfToken = "";
let currentUser = null;

async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (options.method && options.method !== "GET") headers["x-csrf-token"] = csrfToken;
  const response = await fetch(path, { credentials: "same-origin", ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "تعذر إكمال الطلب.");
  return data;
}
async function refreshCsrf() {
  const data = await api("/api/auth/csrf");
  csrfToken = data.csrfToken;
}
function message(text, type="error") {
  const box=$("#message"); box.textContent=text; box.className=`message show ${type}`;
}
function clearMessage(){ $("#message").className="message"; $("#message").textContent=""; }
function switchTab(tab) {
  clearMessage();
  $("#loginPanel").classList.toggle("hidden",tab!=="login");
  $("#registerPanel").classList.toggle("hidden",tab!=="register");
  $("#forgotPanel").classList.add("hidden");
  $$(".tab").forEach(x=>x.classList.toggle("active",x.dataset.tab===tab));
}
function $$(s){return [...document.querySelectorAll(s)]}
$$(".tab").forEach(b=>b.addEventListener("click",()=>switchTab(b.dataset.tab)));
$$(".show-pass").forEach(b=>b.addEventListener("click",()=>{
  const input=b.parentElement.querySelector("input");
  input.type=input.type==="password"?"text":"password";
  b.textContent=input.type==="password"?"إظهار":"إخفاء";
}));
$("#forgotLink").addEventListener("click",()=>{clearMessage();$("#loginPanel").classList.add("hidden");$("#registerPanel").classList.add("hidden");$("#forgotPanel").classList.remove("hidden");$$(".tab").forEach(x=>x.classList.remove("active"));});
$$(".backLogin").forEach(b=>b.addEventListener("click",()=>switchTab("login")));

// Use an explicit button handler for reliable navigation on touch devices.
const openWorldButton = document.querySelector("#openWorld");
if (openWorldButton) {
  openWorldButton.addEventListener("click", () => {
    window.location.assign("/world.html");
  });
}

function showWelcome(user) {
  currentUser=user;
  $(".auth-card").classList.add("hidden");
  $("#welcomePanel").classList.remove("hidden");
  $("#welcomeName").textContent=user.student?.displayName || user.email;
  $("#welcomeSchool").textContent=user.student?.schoolName ? `المدرسة: ${user.student.schoolName}` : "";
  const emoji=user.student?.character==="RACER"?"🦸🏻‍♂️":"🕵🏻‍♀️";
  $("#welcomeAvatar").textContent=emoji+" "+(user.student?.accessory || "✨");
  $("#welcomeAvatar").style.filter=`drop-shadow(0 0 25px ${user.student?.avatarColor || "#8b6ce8"})`;
}
$("#loginForm").addEventListener("submit",async e=>{
  e.preventDefault();clearMessage();
  const form=new FormData(e.currentTarget);
  try {
    const data=await api("/api/auth/login",{method:"POST",body:JSON.stringify(Object.fromEntries(form))});
    await refreshCsrf();showWelcome(data.user);
  } catch(err){message(err.message);}
});
$("#registerForm").addEventListener("submit",async e=>{
  e.preventDefault();clearMessage();
  const form=new FormData(e.currentTarget);
  const payload=Object.fromEntries(form);
  if(payload.password!==payload.confirmPassword){message("كلمتا المرور غير متطابقتين.");return;}
  try {
    const data=await api("/api/auth/register",{method:"POST",body:JSON.stringify(payload)});
    await refreshCsrf();showWelcome(data.user);message(data.message,"success");
  } catch(err){message(err.message);}
});
$("#logoutBtn").addEventListener("click",async()=>{
  try {
    await api("/api/auth/logout",{method:"POST",body:"{}"});
    await refreshCsrf();currentUser=null;$("#welcomePanel").classList.add("hidden");$(".auth-card").classList.remove("hidden");switchTab("login");
  } catch(err){message(err.message);}
});
(async()=>{
  try {
    await refreshCsrf();
    const data=await api("/api/auth/me");
    showWelcome(data.user);
  } catch {}
})();
