(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const screens = ["welcomeScreen","aboutScreen","nameScreen","characterScreen","customizeScreen","homeScreen"];
  const state = {name:"", character:"detective", color:"#8b6ce8", accessory:"✨", school:"", sound:false, reducedMotion:false};
  const characterEmoji = {detective:"🕵🏻‍♀️", racer:"🦸🏻‍♂️"};
  const stories = {detective:"مستعدة لاكتشاف الأدلة وحل الألغاز!", racer:"مستعد للانطلاق في السباقات والتحديات!"};
  function showScreen(id){
    screens.forEach(x => $("#"+x).classList.toggle("active",x===id));
    window.scrollTo({top:0,behavior:state.reducedMotion?"auto":"smooth"});
  }
  function toast(message){
    const el=$("#toast"); el.textContent=message; el.classList.add("show");
    clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove("show"),2300);
  }
  function renderAvatar(){
    const emoji=characterEmoji[state.character];
    $("#liveAvatar").textContent=emoji+" "+state.accessory;
    $("#liveAvatar").style.filter=`drop-shadow(0 15px 12px #080f26aa)`;
    $(".avatar-glow").style.background=state.color;
    document.documentElement.style.setProperty("--hero-color",state.color);
    $("#previewName").textContent=state.name || "بطلك";
    $("#characterStory").textContent=stories[state.character];
    $("#homeAvatar").textContent=emoji+" "+state.accessory;
  }
  $("#startBtn").addEventListener("click",()=>showScreen("nameScreen"));
  $("#aboutBtn").addEventListener("click",()=>showScreen("aboutScreen"));
  $("#aboutContinue").addEventListener("click",()=>showScreen("nameScreen"));
  $$(".backWelcome").forEach(b=>b.addEventListener("click",()=>showScreen("welcomeScreen")));
  $("#nameContinue").addEventListener("click",()=>{
    const name=$("#playerName").value.trim();
    if(name.length<2){$("#nameError").textContent="يرجى كتابة اسم يتكوّن من حرفين على الأقل.";$("#playerName").focus();return;}
    $("#nameError").textContent=""; state.name=name; $("#previewName").textContent=name;
    showScreen("characterScreen");
  });
  $("#playerName").addEventListener("input",()=>$("#nameError").textContent="");
  $$(".character-card").forEach(card=>card.addEventListener("click",()=>{
    state.character=card.dataset.character;
    $$(".character-card").forEach(c=>{c.classList.toggle("selected",c===card);c.setAttribute("aria-pressed",c===card?"true":"false");});
    $("#characterContinue").disabled=false;
  }));
  $("#characterBack").addEventListener("click",()=>showScreen("nameScreen"));
  $("#characterContinue").addEventListener("click",()=>{renderAvatar();showScreen("customizeScreen");});
  $$(".swatch").forEach(b=>b.addEventListener("click",()=>{
    state.color=b.dataset.color; $$(".swatch").forEach(x=>x.classList.toggle("selected",x===b)); renderAvatar();
  }));
  $$(".accessory").forEach(b=>b.addEventListener("click",()=>{
    state.accessory=b.dataset.accessory; $$(".accessory").forEach(x=>x.classList.toggle("selected",x===b)); renderAvatar();
  }));
  $("#customBack").addEventListener("click",()=>showScreen("characterScreen"));
  $("#finishBtn").addEventListener("click",()=>{
    state.school=$("#schoolInput").value.trim(); $("#homeName").textContent=state.name; renderAvatar(); showScreen("homeScreen");
    toast("مرحباً "+state.name+"! عالمك جاهز للاستكشاف.");
  });

  // Interactive mini-games for all five worlds.
  const gameSets = {
    "أكاديمية الضرب": [
      ["ما ناتج ٦ × ٧؟",["٣٦","٤٢","٤٨"],1,"٦ مجموعات من ٧ تساوي ٤٢."],
      ["ما ناتج ٨ × ٥؟",["٣٥","٤٠","٤٥"],1,"٨ مجموعات من ٥ تساوي ٤٠."],
      ["ما ناتج ٩ × ٣؟",["٢٧","٢٤","٣٦"],0,"٩ + ٩ + ٩ = ٢٧."],
      ["ما ناتج ٤ × ٦؟",["١٨","٢٤","٢٨"],1,"٤ مجموعات من ٦ تساوي ٢٤."],
      ["ما ناتج ٧ × ٧؟",["٤٩","٤٢","٥٦"],0,"٧ × ٧ = ٤٩."],
      ["ما ناتج ١٢ × ٢؟",["١٢","٢٢","٢٤"],2,"ضعف ١٢ يساوي ٢٤."]
    ],
    "مملكة العوامل": [
      ["أي عدد عامل للعدد ١٢؟",["٥","٣","٧"],1,"١٢ ÷ ٣ = ٤ دون باقٍ."],
      ["أي زوج عوامله يعطي ١٨؟",["٢ و٩","٤ و٥","٣ و٧"],0,"٢ × ٩ = ١٨."],
      ["كم عاملًا موجبًا للعدد ٧؟",["١","٢","٣"],1,"العددان ١ و٧ فقط."],
      ["أي عدد ليس عاملًا للعدد ٢٠؟",["٢","٤","٦"],2,"٢٠ لا يقبل القسمة على ٦ دون باقٍ."],
      ["ما العامل المشترك الأكبر بين ٨ و١٢؟",["٢","٤","٦"],1,"العوامل المشتركة ١ و٢ و٤، والأكبر ٤."],
      ["أي عدد يقسم ٢٤؟",["٥","٧","٨"],2,"٢٤ ÷ ٨ = ٣."]
    ],
    "مدينة الأعداد الأولية": [
      ["أي عدد أولي؟",["٩","١١","١٥"],1,"١١ لا يقبل القسمة إلا على ١ و١١."],
      ["هل العدد ١ عدد أولي؟",["نعم","لا","أحيانًا"],1,"العدد الأولي له عاملان موجبان مختلفان، و١ له عامل واحد."],
      ["أي عدد مركب؟",["١٣","١٧","٢١"],2,"٢١ = ٣ × ٧."],
      ["ما العدد الأولي الزوجي الوحيد؟",["٢","٤","٦"],0,"٢ هو الأولي الزوجي الوحيد."],
      ["هل ٢٩ عدد أولي؟",["نعم","لا","لا يمكن التحديد"],0,"لا يقبل القسمة على ٢ أو ٣ أو ٥، فهو أولي."],
      ["أي عدد ليس أوليًا؟",["١٩","٢٣","٢٥"],2,"٢٥ = ٥ × ٥."]
    ],
    "رحلة التأسيس": [
      ["ما ناتج ٣٥ + ٢٧؟",["٥٢","٦٢","٦٤"],1,"٣٥ + ٢٧ = ٦٢."],
      ["ما ناتج ٨٠ − ٣٦؟",["٤٤","٥٤","٤٦"],0,"٨٠ − ٣٠ = ٥٠ ثم نطرح ٦ فيصبح ٤٤."],
      ["ما ناتج ٦ × ٤؟",["٢٠","٢٤","٢٨"],1,"٦ مجموعات من ٤ تساوي ٢٤."],
      ["ما ناتج ٤٨ ÷ ٦؟",["٦","٧","٨"],2,"٦ × ٨ = ٤٨."],
      ["أي كسر يساوي النصف؟",["١/٣","٢/٤","٣/٤"],1,"٢/٤ تُبسط إلى ١/٢."],
      ["ما العدد التالي: ٥، ١٠، ١٥، ...؟",["١٨","٢٠","٢٥"],1,"النمط يزيد بمقدار ٥."]
    ],
    "تحديات الأبطال": [
      ["معك ٣ أكياس، في كل كيس ٦ كرات. كم كرة؟",["١٨","١٦","٢٤"],0,"٣ × ٦ = ١٨."],
      ["عدد يقبل القسمة على ٢ و٣ معًا؟",["١٤","١٨","٢٥"],1,"١٨ عدد زوجي ومجموع أرقامه ٩، فيقبل القسمة على ٣."],
      ["ما العدد الأكبر؟",["٠٫٧","٠٫٥","٠٫٦"],0,"٧ أعشار أكبر من ٦ أعشار و٥ أعشار."],
      ["محيط مربع طول ضلعه ٥ سم؟",["١٠ سم","١٥ سم","٢٠ سم"],2,"محيط المربع = ٤ × طول الضلع."],
      ["ما ناتج ١٠٠ ÷ ٤؟",["٢٠","٢٥","٤٠"],1,"٢٥ × ٤ = ١٠٠."],
      ["أي عدد من التالي من مضاعفات ٩؟",["٣٢","٤٥","٥٢"],1,"٤٥ = ٩ × ٥."]
    ]
  };
  const gameStyle = document.createElement("style");
  gameStyle.textContent = `
    .game-overlay{position:fixed;inset:0;z-index:9999;background:#10172bd9;display:grid;place-items:center;padding:16px;overflow:auto}
    .game-panel{width:min(650px,100%);background:#fff;border-radius:24px;padding:clamp(20px,4vw,34px);color:#202744;box-shadow:0 24px 80px #0006;direction:rtl}
    .game-top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
    .game-progress{height:9px;background:#e9eaf4;border-radius:20px;overflow:hidden;margin:18px 0}
    .game-progress>span{display:block;height:100%;background:#7d68d8;transition:width .2s}
    .game-question{font-size:clamp(21px,4vw,29px);line-height:1.6;margin:18px 0}
    .game-options{display:grid;grid-template-columns:1fr;gap:10px}
    .game-option{border:2px solid #e4e5f0;border-radius:14px;background:#f8f8fc;padding:14px;font-size:18px;color:#202744;text-align:right;cursor:pointer}
    .game-option:disabled{cursor:default;opacity:1}
    .game-option.correct{border-color:#24976c;background:#e9f8f0}
    .game-option.wrong{border-color:#d75c68;background:#fff0f1}
    .game-feedback{min-height:52px;margin:14px 0;line-height:1.7;font-weight:600}
    .game-actions{display:flex;gap:10px;justify-content:space-between;align-items:center;flex-wrap:wrap}
    .game-primary,.game-close{border:0;border-radius:12px;padding:12px 20px;font-weight:700;cursor:pointer}
    .game-primary{background:#7562d2;color:white}.game-close{background:#eef0f7;color:#29314c}
    .game-result{text-align:center;padding:16px 0}.game-result strong{font-size:42px;color:#705bd0}
  `;
  document.head.appendChild(gameStyle);
  function startGame(world){
    const questions = gameSets[world] || gameSets["تحديات الأبطال"];
    let index=0, score=0, answered=false;
    const overlay=document.createElement("div"); overlay.className="game-overlay";
    overlay.innerHTML=`<section class="game-panel" role="dialog" aria-modal="true" aria-label="${world}">
      <div class="game-top"><b>🗺️ ${world}</b><button class="game-close" type="button">إغلاق ✕</button></div>
      <div class="game-progress"><span></span></div><div class="game-meta"></div>
      <h2 class="game-question"></h2><div class="game-options"></div><p class="game-feedback" aria-live="polite"></p>
      <div class="game-actions"><span class="game-score">⭐ ٠ نقطة</span><button class="game-primary" type="button" disabled>السؤال التالي ←</button></div>
    </section>`;
    document.body.appendChild(overlay);
    const close=()=>overlay.remove();
    overlay.querySelector(".game-close").addEventListener("click",close);
    overlay.addEventListener("click",e=>{if(e.target===overlay)close();});
    const render=()=>{
      answered=false;
      const q=questions[index];
      overlay.querySelector(".game-meta").textContent=`السؤال ${index+1} من ${questions.length}`;
      overlay.querySelector(".game-progress span").style.width=`${index/questions.length*100}%`;
      overlay.querySelector(".game-question").textContent=q[0];
      overlay.querySelector(".game-feedback").textContent="";
      overlay.querySelector(".game-primary").disabled=true;
      overlay.querySelector(".game-primary").textContent=index===questions.length-1?"عرض النتيجة":"السؤال التالي ←";
      const opts=overlay.querySelector(".game-options"); opts.innerHTML="";
      q[1].forEach((choice,i)=>{
        const btn=document.createElement("button");btn.className="game-option";btn.type="button";btn.textContent=choice;
        btn.addEventListener("click",()=>{
          if(answered)return;answered=true;
          const correct=i===q[2];if(correct)score+=10;
          [...opts.children].forEach((el,j)=>{el.disabled=true;if(j===q[2])el.classList.add("correct");else if(j===i)el.classList.add("wrong");});
          overlay.querySelector(".game-feedback").textContent=(correct?"أحسنت! إجابة صحيحة 🌟 ":"حاول مرة أخرى! ") + q[3];
          overlay.querySelector(".game-score").textContent=`⭐ ${score} نقطة`;
          overlay.querySelector(".game-primary").disabled=false;
        });
        opts.appendChild(btn);
      });
    };
    overlay.querySelector(".game-primary").addEventListener("click",()=>{
      if(!answered)return;
      if(index<questions.length-1){index++;render();return;}
      const panel=overlay.querySelector(".game-panel");
      panel.innerHTML=`<div class="game-result"><div style="font-size:48px">🏆</div><h2>أحسنت يا بطل!</h2><p>أنهيت ${world}</p><strong>${score} / ${questions.length*10}</strong><p>نقطة خبرة مكتسبة في هذه الجولة</p><button class="game-primary" type="button">العودة إلى خريطة العوالم</button></div>`;
      panel.querySelector("button").addEventListener("click",close);
    });
    render();
  }
  $$(".world-card").forEach(b=>b.addEventListener("click",()=>startGame(b.dataset.world)));

  $("#restartBtn").addEventListener("click",()=>{
    state.name="";state.character="detective";state.color="#8b6ce8";state.accessory="✨";
    $("#playerName").value="";$("#schoolInput").value="";$("#characterContinue").disabled=true;
    $$(".character-card").forEach(c=>{c.classList.remove("selected");c.setAttribute("aria-pressed","false");});
    $$(".swatch").forEach((x,i)=>x.classList.toggle("selected",i===0));
    $$(".accessory").forEach((x,i)=>x.classList.toggle("selected",i===0));
    showScreen("welcomeScreen");toast("تمت إعادة ضبط التجربة.");
  });
  $("#soundToggle").addEventListener("click",()=>{
    state.sound=!state.sound;$("#soundLabel").textContent="الصوت: "+(state.sound?"مفعّل":"مغلق");
    toast(state.sound?"تم تفعيل خيار الصوت (لا توجد ملفات صوتية في هذه النسخة).":"تم إغلاق خيار الصوت.");
  });
  $("#motionToggle").addEventListener("click",()=>{
    state.reducedMotion=!state.reducedMotion;document.body.classList.toggle("reduce-motion",state.reducedMotion);
    $("#motionLabel").textContent="الحركة: "+(state.reducedMotion?"مخفّضة":"مفعّلة");
    toast(state.reducedMotion?"تم تقليل الحركة.":"تمت إعادة الحركة.");
  });
  // Load the authenticated student profile before showing the adventure map.
  (async () => {
    try {
      const response = await fetch("/api/auth/me", { credentials: "same-origin" });
      if (!response.ok) { window.location.replace("/"); return; }
      const data = await response.json();
      const user = data.user;
      if (!user) { window.location.replace("/"); return; }
      state.name = user.student?.displayName || user.email || "بطلنا";
      state.character = user.student?.character === "RACER" ? "racer" : "detective";
      state.color = user.student?.avatarColor || "#8b6ce8";
      state.accessory = user.student?.accessory || "✨";
      state.school = user.student?.schoolName || "";
      $("#homeName").textContent = state.name;
      renderAvatar();
      showScreen("homeScreen");
    } catch (error) {
      window.location.replace("/");
    }
  })();
})();