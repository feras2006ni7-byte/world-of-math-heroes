(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const screens = ["welcomeScreen","aboutScreen","nameScreen","characterScreen","customizeScreen","homeScreen"];
  const state = {name:"", character:"detective", color:"#8b6ce8", accessory:"✨", school:"", sound:false, reducedMotion:false};
  const characterEmoji = {detective:"🕵🏻‍♀️", racer:"🦸🏻‍♂️"};
  const stories = {detective:"مستعدة لاكتشاف الأدلة وحل الألغاز!", racer:"مستعد للانطلاق في السباقات والتحديات!"};
  function showScreen(id){
    screens.forEach(x => $("#"+x).classList.toggle("active",x===id));
    window.scrollTo({top:0,behavior:state.reducedMotion?"auto":"smooth"});
  }
  function toast(message){
    const el=$("#toast"); el.textContent=message; el.classList.add("show");
    clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove("show"),2300);
  }
  function renderAvatar(){
    const emoji=characterEmoji[state.character];
    $("#liveAvatar").textContent=emoji+" "+state.accessory;
    $("#liveAvatar").style.filter=`drop-shadow(0 15px 12px #080f26aa)`;
    $(".avatar-glow").style.background=state.color;
    document.documentElement.style.setProperty("--hero-color",state.color);
    $("#previewName").textContent=state.name || "بطلك";
    $("#characterStory").textContent=stories[state.character];
    $("#homeAvatar").textContent=emoji+" "+state.accessory;
  }
  $("#startBtn").addEventListener("click",()=>showScreen("nameScreen"));
  $("#aboutBtn").addEventListener("click",()=>showScreen("aboutScreen"));
  $("#aboutContinue").addEventListener("click",()=>showScreen("nameScreen"));
  $$(".backWelcome").forEach(b=>b.addEventListener("click",()=>showScreen("welcomeScreen")));
  $("#nameContinue").addEventListener("click",()=>{
    const name=$("#playerName").value.trim();
    if(name.length<2){$("#nameError").textContent="يرجى كتابة اسم يتكوّن من حرفين على الأقل.";$("#playerName").focus();return;}
    $("#nameError").textContent=""; state.name=name; $("#previewName").textContent=name;
    showScreen("characterScreen");
  });
  $("#playerName").addEventListener("input",()=>$("#nameError").textContent="");
  $$(".character-card").forEach(card=>card.addEventListener("click",()=>{
    state.character=card.dataset.character;
    $$(".character-card").forEach(c=>{c.classList.toggle("selected",c===card);c.setAttribute("aria-pressed",c===card?"true":"false");});
    $("#characterContinue").disabled=false;
  }));
  $("#characterBack").addEventListener("click",()=>showScreen("nameScreen"));
  $("#characterContinue").addEventListener("click",()=>{renderAvatar();showScreen("customizeScreen");});
  $$(".swatch").forEach(b=>b.addEventListener("click",()=>{
    state.color=b.dataset.color; $$(".swatch").forEach(x=>x.classList.toggle("selected",x===b)); renderAvatar();
  }));
  $$(".accessory").forEach(b=>b.addEventListener("click",()=>{
    state.accessory=b.dataset.accessory; $$(".accessory").forEach(x=>x.classList.toggle("selected",x===b)); renderAvatar();
  }));
  $("#customBack").addEventListener("click",()=>showScreen("characterScreen"));
  $("#finishBtn").addEventListener("click",()=>{
    state.school=$("#schoolInput").value.trim(); $("#homeName").textContent=state.name; renderAvatar(); showScreen("homeScreen");
    toast("مرحباً "+state.name+"! عالمك جاهز للاستكشاف.");
  });

  // Interactive mini-games for all five worlds.
  const gameSets = {
    "أكاديمية الضرب": [
      ["ما ناتج 6 × 7؟",["36","42","48"],1,"6 مجموعات من 7 تساوي 42."],
      ["ما ناتج 8 × 5؟",["35","40","45"],1,"8 مجموعات من 5 تساوي 40."],
      ["ما ناتج 9 × 3؟",["27","24","36"],0,"9 + 9 + 9 = 27."],
      ["ما ناتج 4 × 6؟",["18","24","28"],1,"4 مجموعات من 6 تساوي 24."],
      ["ما ناتج 7 × 7؟",["49","42","56"],0,"7 × 7 = 49."],
      ["ما ناتج 12 × 2؟",["12","22","24"],2,"ضعف 12 يساوي 24."]
    ],
    "مملكة العوامل": [
      ["أي عدد عامل للعدد 12؟",["5","3","7"],1,"12 ÷ 3 = 4 دون باقٍ."],
      ["أي زوج عوامله يعطي 18؟",["2 و9","4 و5","3 و7"],0,"2 × 9 = 18."],
      ["كم عاملًا موجبًا للعدد 7؟",["1","2","3"],1,"العددان 1 و7 فقط."],
      ["أي عدد ليس عاملًا للعدد 20؟",["2","4","6"],2,"20 لا يقبل القسمة على 6 دون باقٍ."],
      ["ما العامل المشترك الأكبر بين 8 و12؟",["2","4","6"],1,"العوامل المشتركة 1 و2 و4، والأكبر 4."],
      ["أي عدد يقسم 24؟",["5","7","8"],2,"24 ÷ 8 = 3."]
    ],
    "مدينة الأعداد الأولية": [
      ["أي عدد أولي؟",["9","11","15"],1,"11 لا يقبل القسمة إلا على 1 و11."],
      ["هل العدد 1 عدد أولي؟",["نعم","لا","أحيانًا"],1,"العدد الأولي له عاملان موجبان مختلفان، و1 له عامل واحد."],
      ["أي عدد مركب؟",["13","17","21"],2,"21 = 3 × 7."],
      ["ما العدد الأولي الزوجي الوحيد؟",["2","4","6"],0,"2 هو الأولي الزوجي الوحيد."],
      ["هل 29 عدد أولي؟",["نعم","لا","لا يمكن التحديد"],0,"لا يقبل القسمة على 2 أو 3 أو 5، فهو أولي."],
      ["أي عدد ليس أوليًا؟",["19","23","25"],2,"25 = 5 × 5."]
    ],
    "رحلة التأسيس": [
      ["ما ناتج 35 + 27؟",["52","62","64"],1,"35 + 27 = 62."],
      ["ما ناتج 80 − 36؟",["44","54","46"],0,"80 − 30 = 50 ثم نطرح 6 فيصبح 44."],
      ["ما ناتج 6 × 4؟",["20","24","28"],1,"6 مجموعات من 4 تساوي 24."],
      ["ما ناتج 48 ÷ 6؟",["6","7","8"],2,"6 × 8 = 48."],
      ["أي كسر يساوي النصف؟",["1/3","2/4","3/4"],1,"2/4 تُبسط إلى 1/2."],
      ["ما العدد التالي: 5، 10، 15، ...؟",["18","20","25"],1,"النمط يزيد بمقدار 5."]
    ],
    "تحديات الأبطال": [
      ["معك 3 أكياس، في كل كيس 6 كرات. كم كرة؟",["18","16","24"],0,"3 × 6 = 18."],
      ["عدد يقبل القسمة على 2 و3 معًا؟",["14","18","25"],1,"18 عدد زوجي ومجموع أرقامه 9، فيقبل القسمة على 3."],
      ["ما العدد الأكبر؟",["0٫7","0٫5","0٫6"],0,"7 أعشار أكبر من 6 أعشار و5 أعشار."],
      ["محيط مربع طول ضلعه 5 سم؟",["10 سم","15 سم","20 سم"],2,"محيط المربع = 4 × طول الضلع."],
      ["ما ناتج 100 ÷ 4؟",["20","25","40"],1,"25 × 4 = 100."],
      ["أي عدد من التالي من مضاعفات 9؟",["32","45","52"],1,"45 = 9 × 5."]
    ]
  };
  const gameStyle = document.createElement("style");
  gameStyle.textContent = `
    .game-overlay{position:fixed;inset:0;z-index:9999;background:#10172bd9;display:grid;place-items:center;padding:16px;overflow:auto}
    .game-panel{width:min(650px,100%);background:#fff;border-radius:24px;padding:clamp(20px,4vw,34px);color:#202744;box-shadow:0 24px 80px #0006;direction:rtl}
    .game-top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
    .game-progress{height:9px;background:#e9eaf4;border-radius:20px;overflow:hidden;margin:18px 0}
    .game-progress>span{display:block;height:100%;background:#7d68d8;transition:width .2s}
    .game-question{font-size:clamp(21px,4vw,29px);line-height:1.6;margin:18px 0}
    .game-options{display:grid;grid-template-columns:1fr;gap:10px}
    .game-option{border:2px solid #e4e5f0;border-radius:14px;background:#f8f8fc;padding:14px;font-size:18px;color:#202744;text-align:right;cursor:pointer}
    .game-option:disabled{cursor:default;opacity:1}
    .game-option.correct{border-color:#24976c;background:#e9f8f0}
    .game-option.wrong{border-color:#d75c68;background:#fff0f1}
    .game-feedback{min-height:52px;margin:14px 0;line-height:1.7;font-weight:600}
    .game-actions{display:flex;gap:10px;justify-content:space-between;align-items:center;flex-wrap:wrap}
    .game-primary,.game-close{border:0;border-radius:12px;padding:12px 20px;font-weight:700;cursor:pointer}
    .game-primary{background:#7562d2;color:white}.game-close{background:#eef0f7;color:#29314c}
    .game-result{text-align:center;padding:16px 0}.game-result strong{font-size:42px;color:#705bd0}
  `;
  document.head.appendChild(gameStyle);
  function startGame(world){
    const questions = gameSets[world] || gameSets["تحديات الأبطال"];
    let index=0, score=0, answered=false;
    const overlay=document.createElement("div"); overlay.className="game-overlay";
    overlay.innerHTML=`<section class="game-panel" role="dialog" aria-modal="true" aria-label="${world}">
      <div class="game-top"><b>🗺️ ${world}</b><button class="game-close" type="button">إغلاق ✕</button></div>
      <div class="game-progress"><span></span></div><div class="game-meta"></div>
      <h2 class="game-question"></h2><div class="game-options"></div><p class="game-feedback" aria-live="polite"></p>
      <div class="game-actions"><span class="game-score">⭐ 0 نقطة</span><button class="game-primary" type="button" disabled>السؤال التالي ←</button></div>
    </section>`;
    document.body.appendChild(overlay);
    const close=()=>overlay.remove();
    overlay.querySelector(".game-close").addEventListener("click",close);
    overlay.addEventListener("click",e=>{if(e.target===overlay)close();});
    const render=()=>{
      answered=false;
      const q=questions[index];
      overlay.querySelector(".game-meta").textContent=`السؤال ${index+1} من ${questions.length}`;
      overlay.querySelector(".game-progress span").style.width=`${index/questions.length*100}%`;
      overlay.querySelector(".game-question").textContent=q[0];
      overlay.querySelector(".game-feedback").textContent="";
      overlay.querySelector(".game-primary").disabled=true;
      overlay.querySelector(".game-primary").textContent=index===questions.length-1?"عرض النتيجة":"السؤال التالي ←";
      const opts=overlay.querySelector(".game-options"); opts.innerHTML="";
      q[1].forEach((choice,i)=>{
        const btn=document.createElement("button");btn.className="game-option";btn.type="button";btn.textContent=choice;
        btn.addEventListener("click",()=>{
          if(answered)return;answered=true;
          const correct=i===q[2];if(correct)score+=10;
          [...opts.children].forEach((el,j)=>{el.disabled=true;if(j===q[2])el.classList.add("correct");else if(j===i)el.classList.add("wrong");});
          overlay.querySelector(".game-feedback").textContent=(correct?"أحسنت! إجابة صحيحة 🌟 ":"حاول مرة أخرى! ") + q[3];
          overlay.querySelector(".game-score").textContent=`⭐ ${score} نقطة`;
          overlay.querySelector(".game-primary").disabled=false;
        });
        opts.appendChild(btn);
      });
    };
    overlay.querySelector(".game-primary").addEventListener("click",()=>{
      if(!answered)return;
      if(index<questions.length-1){index++;render();return;}
      const panel=overlay.querySelector(".game-panel");
      panel.innerHTML=`<div class="game-result"><div style="font-size:48px">🏆</div><h2>أحسنت يا بطل!</h2><p>أنهيت ${world}</p><strong>${score} / ${questions.length*10}</strong><p>نقطة خبرة مكتسبة في هذه الجولة</p><button class="game-primary" type="button">العودة إلى خريطة العوالم</button></div>`;
      panel.querySelector("button").addEventListener("click",close);
    });
    render();
  }
  $$(".world-card").forEach(b=>b.addEventListener("click",()=>startGame(b.dataset.world)));

  $("#restartBtn").addEventListener("click",()=>{
    state.name="";state.character="detective";state.color="#8b6ce8";state.accessory="✨";
    $("#playerName").value="";$("#schoolInput").value="";$("#characterContinue").disabled=true;
    $$(".character-card").forEach(c=>{c.classList.remove("selected");c.setAttribute("aria-pressed","false");});
    $$(".swatch").forEach((x,i)=>x.classList.toggle("selected",i===0));
    $$(".accessory").forEach((x,i)=>x.classList.toggle("selected",i===0));
    showScreen("welcomeScreen");toast("تمت إعادة ضبط التجربة.");
  });
  $("#soundToggle").addEventListener("click",()=>{
    state.sound=!state.sound;$("#soundLabel").textContent="الصوت: "+(state.sound?"مفعّل":"مغلق");
    toast(state.sound?"تم تفعيل خيار الصوت (لا توجد ملفات صوتية في هذه النسخة).":"تم إغلاق خيار الصوت.");
  });
  $("#motionToggle").addEventListener("click",()=>{
    state.reducedMotion=!state.reducedMotion;document.body.classList.toggle("reduce-motion",state.reducedMotion);
    $("#motionLabel").textContent="الحركة: "+(state.reducedMotion?"مخفّضة":"مفعّلة");
    toast(state.reducedMotion?"تم تقليل الحركة.":"تمت إعادة الحركة.");
  });
  // Load the authenticated student profile before showing the adventure map.
  (async () => {
    try {
      const response = await fetch("/api/auth/me", { credentials: "same-origin" });
      if (!response.ok) { window.location.replace("/"); return; }
      const data = await response.json();
      const user = data.user;
      if (!user) { window.location.replace("/"); return; }
      state.name = user.student?.displayName || user.email || "بطلنا";
      state.character = user.student?.character === "RACER" ? "racer" : "detective";
      state.color = user.student?.avatarColor || "#8b6ce8";
      state.accessory = user.student?.accessory || "✨";
      state.school = user.student?.schoolName || "";
      $("#homeName").textContent = state.name;
      renderAvatar();
      showScreen("homeScreen");
    } catch (error) {
      window.location.replace("/");
    }
  })();
})();