(() => {
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const screens = ["welcomeScreen","aboutScreen","nameScreen","characterScreen","customizeScreen","homeScreen"];
  const state = {name:"", character:"detective", color:"#8b6ce8", accessory:"✨", school:"", sound:false, reducedMotion:false};
  const characterEmoji = {detective:"🕵🏻‍♀️", racer:"🦸🏻‍♂️"};
  const stories = {detective:"مستعدة لاكتشاف الأدلة وحل الألغاز!", racer:"مستعد للانطلاق في السباقات والتحديات!"};
  function showScreen(id){
    screens.forEach(x => $("#"+x).classList.toggle("active",x===id));
    window.scrollTo({top:0,behavior:state.reducedMotion?"auto":"smooth"});
  }
  function toast(message){
    const el=$("#toast"); el.textContent=message; el.classList.add("show");
    clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove("show"),2300);
  }
  function renderAvatar(){
    const emoji=characterEmoji[state.character];
    $("#liveAvatar").textContent=emoji+" "+state.accessory;
    $("#liveAvatar").style.filter=`drop-shadow(0 15px 12px #080f26aa)`;
    $(".avatar-glow").style.background=state.color;
    document.documentElement.style.setProperty("--hero-color",state.color);
    $("#previewName").textContent=state.name || "بطلك";
    $("#characterStory").textContent=stories[state.character];
    $("#homeAvatar").textContent=emoji+" "+state.accessory;
  }
  $("#startBtn").addEventListener("click",()=>showScreen("nameScreen"));
  $("#aboutBtn").addEventListener("click",()=>showScreen("aboutScreen"));
  $("#aboutContinue").addEventListener("click",()=>showScreen("nameScreen"));
  $$(".backWelcome").forEach(b=>b.addEventListener("click",()=>showScreen("welcomeScreen")));
  $("#nameContinue").addEventListener("click",()=>{
    const name=$("#playerName").value.trim();
    if(name.length<2){$("#nameError").textContent="يرجى كتابة اسم يتكوّن من حرفين على الأقل.";$("#playerName").focus();return;}
    $("#nameError").textContent=""; state.name=name; $("#previewName").textContent=name;
    showScreen("characterScreen");
  });
  $("#playerName").addEventListener("input",()=>$("#nameError").textContent="");
  $$(".character-card").forEach(card=>card.addEventListener("click",()=>{
    state.character=card.dataset.character;
    $$(".character-card").forEach(c=>{c.classList.toggle("selected",c===card);c.setAttribute("aria-pressed",c===card?"true":"false");});
    $("#characterContinue").disabled=false;
  }));
  $("#characterBack").addEventListener("click",()=>showScreen("nameScreen"));
  $("#characterContinue").addEventListener("click",()=>{renderAvatar();showScreen("customizeScreen");});
  $$(".swatch").forEach(b=>b.addEventListener("click",()=>{
    state.color=b.dataset.color; $$(".swatch").forEach(x=>x.classList.toggle("selected",x===b)); renderAvatar();
  }));
  $$(".accessory").forEach(b=>b.addEventListener("click",()=>{
    state.accessory=b.dataset.accessory; $$(".accessory").forEach(x=>x.classList.toggle("selected",x===b)); renderAvatar();
  }));
  $("#customBack").addEventListener("click",()=>showScreen("characterScreen"));
  $("#finishBtn").addEventListener("click",()=>{
    state.school=$("#schoolInput").value.trim(); $("#homeName").textContent=state.name; renderAvatar(); showScreen("homeScreen");
    toast("مرحباً "+state.name+"! عالمك جاهز للاستكشاف.");
  });
  $$(".world-card").forEach(b=>b.addEventListener("click",()=>toast("قريباً: "+b.dataset.world+" — سيتم تطوير محتواها في المراحل القادمة.")));
  $("#restartBtn").addEventListener("click",()=>{
    state.name="";state.character="detective";state.color="#8b6ce8";state.accessory="✨";
    $("#playerName").value="";$("#schoolInput").value="";$("#characterContinue").disabled=true;
    $$(".character-card").forEach(c=>{c.classList.remove("selected");c.setAttribute("aria-pressed","false");});
    $$(".swatch").forEach((x,i)=>x.classList.toggle("selected",i===0));
    $$(".accessory").forEach((x,i)=>x.classList.toggle("selected",i===0));
    showScreen("welcomeScreen");toast("تمت إعادة ضبط التجربة.");
  });
  $("#soundToggle").addEventListener("click",()=>{
    state.sound=!state.sound;$("#soundLabel").textContent="الصوت: "+(state.sound?"مفعّل":"مغلق");
    toast(state.sound?"تم تفعيل خيار الصوت (لا توجد ملفات صوتية في هذه النسخة).":"تم إغلاق خيار الصوت.");
  });
  $("#motionToggle").addEventListener("click",()=>{
    state.reducedMotion=!state.reducedMotion;document.body.classList.toggle("reduce-motion",state.reducedMotion);
    $("#motionLabel").textContent="الحركة: "+(state.reducedMotion?"مخفّضة":"مفعّلة");
    toast(state.reducedMotion?"تم تقليل الحركة.":"تمت إعادة الحركة.");
  });
  renderAvatar();
})();